
var radio = document.querySelector('.manual-btn')
var cont = 1

document.getElementById('radio1').checked = true 

setInterval(() => {
    proximaImg()
}, 5000)

function proximaImg(){
    cont++

    if(cont > 3){
      cont = 1
    }

 document.getElementById('radio'+cont).checked = true
}

//Botao voltar ao topo
// Mostra o botão quando o usuário rola a página
window.onscroll = function () {
  const botao = document.getElementById("btnTopo");
  if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
    botao.style.display = "block";
  } else {
    botao.style.display = "none";
  }
}

// Função para rolar até o topo
function voltarAoTopo() {
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
