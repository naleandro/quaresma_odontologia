const nodemailer = require("nodemailer");

// index.js
const express = require("express");
const bodyParser = require("body-parser");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(bodyParser.json());

// Configuração do transportador de e-mail //
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "gabrielcamelo.andrade@uni9.edu.br",
    pass: "mdvi fepc vqqx neqg"
  }
});

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "", // altere se tiver senha
  database: "formulario_contato"
});

db.connect(err => {
  if (err) {
    console.error("Erro ao conectar ao MySQL:", err);
  } else {
    console.log("Conectado ao banco de dados!");
  }
});

app.post("/enviar-formulario", (req, res) => {
  const { nome, email, mensagem } = req.body;

  if (!nome || !email || !mensagem) {
    return res.status(400).send("Todos os campos são obrigatórios.");
  }
  app.get("/", (req, res) => {
  res.send("Servidor rodando corretamente!");
});

  const query = "INSERT INTO mensagens (nome, email, mensagem) VALUES (?, ?, ?)";
  db.query(query, [nome, email, mensagem], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).send("Erro ao salvar a mensagem.");
    }

    // Enviar e-mail
    const mailOptions = {
      from: "gabrielcamelo.andrade@uni9.edu.br",
      to: "gabrielcamelo.andrade@uni9.edu.br", // ou outro destinatário
      subject: "Nova mensagem do formulário",
      text: `Nome: ${nome}\nEmail: ${email}\nMensagem:\n${mensagem}`
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error("Erro ao enviar e-mail:", error);
        return res.status(500).send("Mensagem salva, mas o e-mail não foi enviado.");
      }
      res.send("Mensagem recebida com sucesso e e-mail enviado!");
    });
  });
});

const port = 4000;
app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});

